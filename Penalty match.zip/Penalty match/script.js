let playerScore = 0;
let cpuScore = 0;

let penaltyNumber = 1;

let playerKicks = 0;
let cpuKicks = 0;

let gameOver = false;

let power = 50;

const playerScoreDisplay =
    document.getElementById("playerScore");

const cpuScoreDisplay =
    document.getElementById("cpuScore");

const penaltyDisplay =
    document.getElementById("penaltyNumber");

const goalkeeper =
    document.getElementById("goalkeeper");

const ball =
    document.getElementById("ball");

const message =
    document.getElementById("message");

const powerLevel =
    document.getElementById("powerLevel");

const restartButton =
    document.getElementById("restartButton");

const directionButtons =
    document.querySelectorAll(".direction-buttons button");


// ----------------------------------
// POWER SYSTEM
// ----------------------------------

function chargePower() {

    power += 10;

    if (power > 100) {
        power = 10;
    }

    powerLevel.style.width = power + "%";
}


// ----------------------------------
// PLAYER SHOOTING
// ----------------------------------

function shoot(direction) {

    if (gameOver) {
        return;
    }

    if (playerKicks >= 5) {
        return;
    }

    disableButtons();

    message.textContent = "You shoot...";

    // Random goalkeeper direction
    const goalkeeperDirections = [
        "left",
        "center",
        "right"
    ];

    const keeperDirection =
        goalkeeperDirections[
            Math.floor(
                Math.random() *
                goalkeeperDirections.length
            )
        ];

    // Move goalkeeper
    moveGoalkeeper(keeperDirection);

    // Move ball
    moveBall(direction);

    // Calculate result
    setTimeout(function () {

        let scored = false;

        /*
         * Higher power gives a better chance,
         * but extremely powerful shots can still miss.
         */

        const randomNumber =
            Math.random() * 100;

        const accuracyBonus =
            power >= 70 ? 15 : 0;

        // Keeper saves when guessing correctly
        if (direction === keeperDirection) {

            message.textContent =
                "🧤 SAVED! The goalkeeper guessed correctly!";

        }

        // Very low power can miss
        else if (power < 25) {

            message.textContent =
                "❌ MISS! Too little power!";

        }

        // Very high power has a small chance of going over
        else if (power > 95 && randomNumber < 10) {

            message.textContent =
                "❌ MISS! Too much power!";

        }

        else {

            scored = true;

            playerScore++;

            playerScoreDisplay.textContent =
                playerScore;

            message.textContent =
                "⚽ GOAL! What a finish!";

        }

        playerKicks++;

        updateGame();

    }, 600);
}


// ----------------------------------
// MOVE GOALKEEPER
// ----------------------------------

function moveGoalkeeper(direction) {

    if (direction === "left") {

        goalkeeper.style.left = "20%";
        goalkeeper.style.transform =
            "translateX(-50%) rotate(-20deg)";

    }

    else if (direction === "right") {

        goalkeeper.style.left = "80%";
        goalkeeper.style.transform =
            "translateX(-50%) rotate(20deg)";

    }

    else {

        goalkeeper.style.left = "50%";
        goalkeeper.style.transform =
            "translateX(-50%)";
    }
}


// ----------------------------------
// MOVE BALL
// ----------------------------------

function moveBall(direction) {

    if (direction === "left") {

        ball.style.left = "25%";
        ball.style.bottom = "130px";
        ball.style.transform =
            "translateX(-50%) scale(0.7)";

    }

    else if (direction === "right") {

        ball.style.left = "75%";
        ball.style.bottom = "130px";
        ball.style.transform =
            "translateX(-50%) scale(0.7)";

    }

    else {

        ball.style.left = "50%";
        ball.style.bottom = "145px";
        ball.style.transform =
            "translateX(-50%) scale(0.7)";
    }
}


// ----------------------------------
// CPU PENALTY
// ----------------------------------

function cpuPenalty() {

    if (cpuKicks >= 5) {
        return;
    }

    message.textContent =
        "CPU is taking the penalty...";

    setTimeout(function () {

        const directions = [
            "left",
            "center",
            "right"
        ];

        const cpuDirection =
            directions[
                Math.floor(
                    Math.random() *
                    directions.length
                )
            ];

        const keeperDirection =
            directions[
                Math.floor(
                    Math.random() *
                    directions.length
                )
            ];

        moveGoalkeeper(cpuDirection);

        // CPU shot
        ball.style.left =
            cpuDirection === "left"
                ? "25%"
                : cpuDirection === "right"
                ? "75%"
                : "50%";

        ball.style.bottom = "135px";

        setTimeout(function () {

            if (
                cpuDirection ===
                keeperDirection
            ) {

                message.textContent =
                    "🧤 SAVED! You stopped the CPU!";

            }

            else {

                cpuScore++;

                cpuScoreDisplay.textContent =
                    cpuScore;

                message.textContent =
                    "⚽ CPU SCORES!";
            }

            cpuKicks++;

            updateGame();

        }, 600);

    }, 900);
}


// ----------------------------------
// GAME LOGIC
// ----------------------------------

function updateGame() {

    setTimeout(function () {

        // Reset positions
        ball.style.left = "50%";
        ball.style.bottom = "15px";
        ball.style.transform =
            "translateX(-50%) scale(1)";

        moveGoalkeeper("center");

        // Check whether the shootout is finished
        if (playerKicks >= 5 &&
            cpuKicks >= 5) {

            if (playerScore > cpuScore) {

                endGame(
                    "🏆 YOU WIN! " +
                    playerScore +
                    " - " +
                    cpuScore
                );

            }

            else if (cpuScore > playerScore) {

                endGame(
                    "😢 CPU WINS! " +
                    cpuScore +
                    " - " +
                    playerScore
                );

            }

            else {

                // Sudden death
                penaltyNumber++;

                penaltyDisplay.textContent =
                    penaltyNumber;

                message.textContent =
                    "🔥 SUDDEN DEATH! Next goal wins!";

                playerKicks = 4;
                cpuKicks = 4;

                enableButtons();
            }

            return;
        }


        // Player takes next penalty
        penaltyNumber++;

        penaltyDisplay.textContent =
            penaltyNumber;

        enableButtons();

        // CPU takes its penalty
        cpuPenalty();

    }, 1000);
}


// ----------------------------------
// END GAME
// ----------------------------------

function endGame(finalMessage) {

    gameOver = true;

    message.textContent = finalMessage;

    restartButton.style.display =
        "block";

    disableButtons();
}


// ----------------------------------
// BUTTON CONTROL
// ----------------------------------

function disableButtons() {

    directionButtons.forEach(
        button => button.disabled = true
    );
}

function enableButtons() {

    directionButtons.forEach(
        button => button.disabled = false
    );
}


// ----------------------------------
// RESTART
// ----------------------------------

function restartGame() {

    playerScore = 0;
    cpuScore = 0;

    playerKicks = 0;
    cpuKicks = 0;

    penaltyNumber = 1;

    power = 50;

    gameOver = false;

    playerScoreDisplay.textContent = "0";
    cpuScoreDisplay.textContent = "0";

    penaltyDisplay.textContent = "1";

    powerLevel.style.width = "50%";

    message.textContent =
        "Choose where you want to shoot!";

    restartButton.style.display =
        "none";

    ball.style.left = "50%";
    ball.style.bottom = "15px";

    moveGoalkeeper("center");

    enableButtons();
}